# MOEX Quiz

## Как запустить 

```console
npm i && npm run dev
```
## Как получить скрипт

```console
npm run build
```

После билда он будет лежать по пути `dist/assets/index-XXXXX.js`