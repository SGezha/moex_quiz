# MOEX Quiz

## Как запустить 

```console
npm i && npm run dev
```